package sprint5inlever;

public class Card {
	Suit suit;
	Value value;

	public Card(Suit suit, Value v) {
		this.suit = suit;
		this.value = v;
	}
	public String toString() {
		return suit + " " + value + " (" + value.nummer + ")";
	}
	public boolean isHigherOrEqual(Card c) {
		
		if(this.value.nummer >= c.value.nummer) {
			return true;
		} else {
			return false;
		}
		
	}

}
