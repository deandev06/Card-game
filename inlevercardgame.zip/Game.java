package sprint5inlever;

import java.util.Scanner;

public class Game {

	private int score;
	private Card currentCard;
	private Card nextCard;
	private Deck deck = new Deck();
	private Scanner sc = new Scanner(System.in);

	public void gameTurn() {
		currentCard = deck.getNextCard();
		System.out.println("Score: " + score + "\nDe kaart is: " + currentCard.toString());
		String answer = sc.nextLine();

		nextCard = deck.getNextCard();

		if (answer.equals("hoger") && nextCard.isHigherOrEqual(currentCard)) {
			correct();
		} else if (answer.endsWith("lager") && !nextCard.isHigherOrEqual(currentCard)) {
			correct();
		} else {
			incorrect();
		}

	}

	public void correct() {
		score++;
	}

	public void incorrect() {
		score--;
		System.out.println("Fout! De kaart was: " + nextCard.toString());
	}

	public boolean stillPlayable() {

		if (deck.AreCardsLeft()) {
			return true;
		} else {
			return false;
		}

	}

	public int getScore() {
		return score;

	}

}
