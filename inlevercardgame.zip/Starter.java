package sprint5inlever;

public class Starter {
	public static void main(String[] args) {
		Game game = new Game();

		while(game.stillPlayable()) {
			game.gameTurn();
		}
		
	}
}
