package sprint5inlever;

public enum Suit {

	Harten,
	Ruiten,
	Schoppen,
	Klaver;
	
}
